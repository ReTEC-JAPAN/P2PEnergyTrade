#!/usr/bin/python
# Write code here when the machine starts for the first time...
# Steps:
# 1. Read the initconf file to find the current status, unique identifier etc.
# 2. If it is not registered, launch discovery module.
# 3. If it is already registered, launch the heartbeat and data-collector module

import ecoboxlib as lib
import time
from gpiozero import LED

if __name__ == '__main__':
    def cloud_connect():
        status = lib.get_switchstate('STATUS', 'status')
        p2pstatus = lib.get_switchstate('STATUS','p2ptrade')
        fromgrid = lib.get_switchstate('STATE', 'grid_supply')
        togrid = lib.get_switchstate('STATE', 'grid_dump')
        instled = LED(18)
        regled = LED(17)
        fromgridled = LED(5)
        togridled = LED(12)
        instled.off()
        regled.off()
        fromgridled.off()
        togridled.off()

        if status == 'I':
            instled.blink()
        elif status == 'R':
            regled.blink()
        elif p2pstatus == 'ON':
            instled.blink()
            regled.blink()
        if fromgrid == 'ON':
            fromgridled.blink()
        if togrid == 'ON':
            togridled.blink()
        try:
            if status == 'P':
                token = lib.get_token()
                if token:
                    lib.modify_switchstate('TOKEN', 'token', token)
                    if lib.send_config():
                        lib.modify_switchstate('STATUS', 'status', 'I')
                        print("CONFIG Successfully updated")
                    else:
                        print("CONFIG Update Failed")
            else:
                resp = lib.send_pinger()
                if resp['status']:
                    lib.modify_switchstate('STATUS', 'status', resp['status'])
        except Exception as e:
            print("type error: " + str(e))

    #t = PerpetualTimer(30, cloud_connect())
    #t.start()
    while True:
        cloud_connect()
        time.sleep(10)
    #t.cancel()



