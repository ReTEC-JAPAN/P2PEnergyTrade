#!flask/bin/python
from flask import Flask
from flask_pymongo import PyMongo
import datetime
import time

app = Flask(__name__)
mongosecurity = PyMongo(app,uri="mongodb://localhost:27017/SecurityDB")
mongodatacollector = PyMongo(app,uri="mongodb://localhost:27017/CollectorDB")

def order_check():
    buy_orders = mongosecurity.db.Orders.find_one({'type': 'B', 'status': 'O'})
    sale_orders = mongosecurity.db.Orders.find_one({'type': 'S', 'status': 'O'})
    curtime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    contractid = "SMCNT" + curtime
    if buy_orders and sale_orders:
        for buy_order in buy_orders:
            for sale_order in sale_orders:
                if (buy_order['qty'] == sale_order['qty']) and (buy_order['unitrate'] >= sale_order['unitrate']):
                    # Process Smart Contract
                    insconfig = mongosecurity.db.SmartContract.insert_one(
                        {'contractid': contractid,
                         'timestamp': curtime,
                         'uniqueid-buyer': buy_order['uniqueid'],
                         'uniqueid-seller': sale_order['uniqueid'],
                         'contract-qty': buy_order['qty'],
                         'contract-rate': buy_order['unitrate'],
                         'status': 'E'})  # E-> Executed , F -> Fulfilled , S -> Settled
                    upd_buy_order = mongosecurity.db.Orders.update_one({'orderid': buy_order['orderid']}, {
                        '$set': {'status': 'C', 'contractid': contractid}})
                    upd_sale_order = mongosecurity.db.Orders.update_one({'orderid': sale_order['orderid']}, {
                        '$set': {'status': 'C', 'contractid': contractid}})

                    seller_sw = mongosecurity.db.SwitchState.find({'uniqueid': sale_order['uniqueid']}).sort(
                        {"timestamp": -1}).limit(1)
                    buyer_sw = mongosecurity.db.SwitchState.find({'uniqueid': buy_order['uniqueid']}).sort(
                        {"timestamp": -1}).limit(1)
                    ins_switchstatelog = mongosecurity.db.StateLog.insert_one(
                        {'uniqueid': seller_sw['uniqueid'], 'timestamp': curtime,
                         'pv_supply': seller_sw['pv_supply'],
                         'bat_supply': seller_sw['bat_supply'],
                         'bat_charge': seller_sw['bat_charge'],
                         'ev_charge': seller_sw['ev_charge'],
                         'appl_supply': seller_sw['appl_supply'],
                         'grid_supply': 'OFF',  # seller_sw['grid_supply'],
                         'grid_dump': 'ON'})
                    ins_switchstatelog = mongosecurity.db.StateLog.insert_one(
                        {'uniqueid': buyer_sw['uniqueid'], 'timestamp': curtime,
                         'pv_supply': buyer_sw['pv_supply'],
                         'bat_supply': buyer_sw['bat_supply'],
                         'bat_charge': buyer_sw['bat_charge'],
                         'ev_charge': buyer_sw['ev_charge'],
                         'appl_supply': buyer_sw['appl_supply'],
                         'grid_supply': 'ON',  # buyer_sw['grid_supply'],
                         'grid_dump': 'OFF'})
                    return True
    else:
        print("No Pending Orders to be fulfilled")
        return True

if __name__ == '__main__':
    while True:
        order_check()
        time.sleep(120)