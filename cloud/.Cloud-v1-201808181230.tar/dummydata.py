#!flask/bin/python
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
import datetime



class MongoDBMgmt:
    def __init__(self):
        self.client = MongoClient('localhost', 27017)
        self.db = self.client['SecurityDB']
        self.collection_users = self.db['Users']
        self.collection_devices = self.db['EcoBoxes']
        self.collection_configs = self.db['Configs']
        self.collection_switchstate = self.db['SwitchState']
        self.collection_statelog = self.db['StateLog']
        self.collection_orders = self.db['Orders']

    def insert_user(self):
        self.collection_users.insert_one({
            "userid": "bmohanty",
            "name": "Bikash K Mohanty",
            "passwd": "bmohanty",
            "email": "Bikash.Mohanty@retc.io",
            "billingaddr": "2-3-4 Hanamachi, Adachi-Ku, Tokyo, JAPAN",
            "keypair": ""
        })
        self.collection_users.insert_one({
            "userid": "mmesmer",
            "name": "Martin Mesmer",
            "passwd": "mmesmer",
            "email": "Martin.Mesmer@retc.io",
            "billingaddr": "1-2-3 Mita, Chiyoda-Ku, Tokyo, JAPAN",
            "keypair": ""
        })
        self.collection_users.insert_one({
            "userid": "apachurka",
            "name": "Amaury Pachurka ",
            "passwd": "apachurka",
            "email": "Amaury.Pachurka@retc.io",
            "billingaddr": "#23 Fashion Street, Section-2, Paris",
            "keypair": ""
        })
        self.collection_users.insert_one({
            "userid": "gdooley",
            "name": "Gareth Dooley",
            "passwd": "gdooley",
            "email": "Gareth.Dooley@retc.io",
            "billingaddr": "#675 Hanan Road, 3F, 488,Taichung City, Taiwan",
            "keypair": ""
        })
    def insert_devices(self):
        self.collection_devices.insert_one({
            "srno": "R2018000012345A",
            "address": "4-5, Hanamachi, Iheya, Okinawa, Japan",
            "uniqueid":"", #7712345678901",
            "macaddress":"",
            "ipaddress":"",
            "status":"P",     # "P" -> Provisioned, "I" -> Installed but Unregistered, "R" -> Registered
            "authcode": generate_password_hash("ghrtysT34a", method='sha256'),
            "userid": ""
        })
        self.collection_devices.insert_one({
            "srno": "R2018000012346A",
            "address": "4-6, Takanawa, Minato, Tokyo, Japan",
            "uniqueid": "", #"7712345678902",
            "macaddress": "",
            "ipaddress": "",
            "status": "P",
            "authcode": generate_password_hash("acbfgrR567",method='sha256'),
            "userid": ""
        })
        self.collection_devices.insert_one({
            "srno": "R2018000012347A",
            "address": "4-7, Hannan Road, Taichung City, Taiwan",
            "uniqueid":"", #"7712345678903",
            "macaddress": "",
            "ipaddress": "",
            "status":"P",
            "authcode": generate_password_hash("Gshsry231d",method='sha256'),
            "userid": ""
        })
        self.collection_devices.insert_one({
            "srno": "R2018000012348A",
            "address": "4-8, Pachukra Street, Paris, France",
            "uniqueid": "", #"7712345678904",
            "macaddress": "",
            "ipaddress": "",
            "status": "P",
            "authcode": generate_password_hash("basdgJ834v",method='sha256'),
            "userid": ""
        })

    def insert_statelog(self):
        curtime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        self.collection_statelog.insert_one(
            {'uniqueid': "7712345678903",
             'timestamp': curtime,
             'pv_supply': "ON",
             'bat_supply': "OFF",
             'bat_charge': "ON",
             'ev_charge': "OFF",
             'appl_supply': "ON",
             'grid_supply': "ON",  # buyer_sw['grid_supply'],
             'grid_dump': "OFF"})

    def insert_orders(self):
        curtime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        orderid = "ORD" + curtime
        self.collection_orders.insert_one({'orderid': orderid, 'userid': 'bmohanty',
                                                'uniqueid': "7712345678903",
                                                'timestamp': curtime,
                                                'type': "B",
                                                'qty': 10,
                                                'unitrate': 20,
                                                'status': "O",  # Order is OPEN, C -> Contracted, F -> Fulfilled
                                                'contractid': ""})
        self.collection_orders.insert_one({'orderid': orderid, 'userid': 'mmesmer',
                                                'uniqueid': "7712345678904",
                                                'timestamp': curtime,
                                                'type': "S",
                                                'qty': 10,
                                                'unitrate': 20,
                                                'status': "O",  # Order is OPEN, C -> Contracted, F -> Fulfilled
                                                'contractid': ""})

if __name__ == '__main__':
    dummydata = MongoDBMgmt()
 #   dummydata.collection_users.drop()
 #   dummydata.insert_user()
 #   dummydata.collection_configs.drop()
 #   dummydata.collection_statelog.drop()
 #   dummydata.collection_switchstate.drop()

 #   dummydata.collection_devices.drop()
 #   dummydata.insert_devices()
 #   dummydata.insert_statelog()

#
# { "macaddress": "32:00:10:82:f9:a1", "ipaddress": "192.168.1.1",
#        "pv": "Y", "pv_cap": 10, "pv_desc": "5 x 2kw Solar Panels",
#        "bat": "Y", "bat_cap": 8,"bms": "Y", "bat_desc" : "8kw Li-ion Battery"
#        "ev":"Y", "ev_cap": 400, "evms":"N", "ev_desc" : "Tesla S3 Model",
#        "appl": "Y", "appl_cap": 60, "appl_desc": "Household appliances with 60A circuit breaker"
# }